﻿using AltanSMS.Interfaces;
using AltanSMS.Models;
using AltanSMS.Services;
using AltanSMS.Utils;
using AltanSMS.Views;
using AltanSMS.Views.Transaction;
using Newtonsoft.Json;
using Plugin.Toast;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace AltanSMS.ViewModels.Login
{
    public class LoginViewModel : BaseViewModel
    {
        // Page Fields
        public string UserName { get; set; }
        public string Password { get; set; }
        public ObservableCollection<string> MyDeviceSimNumberList { get; set; }

        public string MobileNumber { get; set; }

        // Helper Fields
        private bool isBusyIndicator;
        public bool IsBusyIndicator
        {
            get { return isBusyIndicator; }
            set { SetProperty(ref isBusyIndicator, value); }
        }

        readonly Encryption objectEncrypt = new Encryption();


        // Commands
        public ICommand LoginUserCommand { protected set; get; }
        public LoginViewModel()
        {
            MessagingCenter.Unsubscribe<App, bool>((App)Application.Current, "StartServiceOnBoot");

            MessagingCenter.Subscribe<App, bool>((App)Application.Current, "StartServiceOnBoot", (sender, IsServiceStarted) =>
            {
                if (IsServiceStarted)
                {
                    DependencyService.Get<IBroadcastSMSReceiverService>().StartForegroundService();
                }
            });

            LoadAPIServices();         
            LoginUserCommand = new Command(LoginUserClicked);
        }

        private async void LoadAPIServices()
        {
            await ModCommon.LoadDefaults();
        }

        private async void LoginUserClicked()
        {
            try
            {
                if (IsValidLoginDetails())
                {
                    try
                    {
                        IsBusyIndicator = true;

                        if (Settings.IsRememberMe)
                        {
                            SaveUserDetailsAsync();
                        }

                        //Send LoginDetails to Server
                        UserDetails objUserDetails = new UserDetails
                        {
                            UserName = UserName,
                            Password = objectEncrypt.Encrypt(Password), //EncryptPassword(Password), ModCommon.EncryptPassword(Password), Password, objectEncrypt.Encrypt(Password)
                            DeviceSimNumber = MobileNumber, //"+91" + MobileNumber
                            IMEINumber = ModCommon.GetIMEINumber() 
                        };

                        var resultData = await WebServiceCall.GetDataFromAPI("Login", objUserDetails);

                        dynamic Result = JsonConvert.DeserializeObject(resultData.ToString());
                        if (Result.Status.ToString() == "1")
                        {
                            Settings.SenderID = Result.SenderId[0];
                            Settings.SenderID2 = Result.SenderId[1];
                            Settings.SenderID3 = Result.SenderId[2];

                            // Comment this Later
                            //Settings.SenderID = "+918080841670"; //"+918080841670";+919595330470
                            //Settings.SenderID2 = "919850490426";

                            // Started SMS Broadcast Receiver
                            if (!Settings.IsSmsServiceStarted)
                            {
                                DependencyService.Get<IBroadcastSMSReceiverService>().StartForegroundService();
                                Settings.IsSmsServiceStarted = true;
                            }

                            Application.Current.MainPage = new AppTabbedPage();
                            IsBusyIndicator = false;
                        }
                        else
                        {
                            CrossToastPopUp.Current.ShowToastError("Invalid Details");
                            ModCommon.LogErrors("ANDROID - LoginViewModel - Login Failed " + JsonConvert.SerializeObject(objUserDetails));
                            IsBusyIndicator = false;
                        }

                    }
                    catch (Exception ex)
                    {
                        ModCommon.LogErrors("ANDROID Error  - LoginViewModel [Inner] - LoginUserClicked : "  + ex.Message.ToString());
                        CrossToastPopUp.Current.ShowToastError("Something went wrong");
                        IsBusyIndicator = false;
                    }

                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - LoginViewModel - LoginUserClicked :" + ex.Message.ToString());

            }
        }

        #region SaveUserNamePassword
        private async Task SaveUserDetailsAsync()
        {
            try
            {
                await SecureStorage.SetAsync("LoginUserName", UserName);
                await SecureStorage.SetAsync("LoginUserPassword", Password);
                await SecureStorage.SetAsync("LoginMobileNumber", MobileNumber);


            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - LoginViewModel - SaveUserDetailsAsync :" + ex.Message.ToString());
            }
        } 
        #endregion

        #region ValidateLoginDetails
        bool IsValidLoginDetails()
        {
            bool isValidLogin = true;

            try
            {
                if (string.IsNullOrEmpty(UserName) && string.IsNullOrWhiteSpace(UserName))
                {
                    isValidLogin = false;
                    CrossToastPopUp.Current.ShowToastError("Please enter user name");
                    return isValidLogin;
                }

                if (string.IsNullOrEmpty(Password) && string.IsNullOrWhiteSpace(Password))
                {
                    isValidLogin = false;
                    CrossToastPopUp.Current.ShowToastError("Please enter password");
                    return isValidLogin;
                }

                if (string.IsNullOrEmpty(MobileNumber) && string.IsNullOrWhiteSpace(MobileNumber))
                {
                    isValidLogin = false;
                    CrossToastPopUp.Current.ShowToastError("Please enter phone number");
                    return isValidLogin;
                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - LoginViewModel - IsValidLoginDetails :"+ ex.Message.ToString());
            }

            return isValidLogin;
        } 
        #endregion

    }
}
