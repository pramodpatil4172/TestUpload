﻿using AltanSMS.Interfaces;
using AltanSMS.Models;
using AltanSMS.Services;
using AltanSMS.Utils;
using Newtonsoft.Json;
using Plugin.Toast;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace AltanSMS.ViewModels.Home
{
    public class HomeViewModel : BaseViewModel
    {
       
        // Page Fields

        private List<TransactionDetails> _transactionDtlsList;
        public List<TransactionDetails> TransactionDtlsList
        {
            get { return _transactionDtlsList; }
            set
            {
                _transactionDtlsList = value;
                OnPropertyChanged();
            }
        }

        private List<BankDetails> _bankList;
        public List<BankDetails> BankList
        {
            get { return _bankList; }
            set
            {
                _bankList = value;
                OnPropertyChanged();
            }
        }

        // Filter Page Fields
        public string UserName { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }

        public DateTime TodayDate { get; set; }

        
        private BankDetails _selectedBank { get; set; }
        public BankDetails SelectedBank
        {
            get => _selectedBank;
            set
            {
                _selectedBank = value;
                OnPropertyChanged(nameof(SelectedBank));
            }
        }


        // Helpers
        List<TransactionDetails> allTransactionDtlData { get; set; }
        List<TransactionDetails> recent20TransDtlList { get; set; }

        bool isRefreshing;
        public bool IsRefreshing
        {
            get => isRefreshing;
            set
            {
                isRefreshing = value;
                OnPropertyChanged(nameof(IsRefreshing));
            }
        }

        private bool isBusyIndicator;
        public bool IsBusyIndicator
        {
            get { return isBusyIndicator; }
            set { SetProperty(ref isBusyIndicator, value); }
        }

        // Commands
        public ICommand RefreshCommand { protected set; get; }
        public ICommand ApplyFilterCommand { protected set; get; }


        public HomeViewModel()
        {

            LoadTransactionData();
            LoadFilterData();
            RefreshCommand = new Command(ExecuteRefreshCommand);
            ApplyFilterCommand = new Command(ExecuteApplyFilterCommand);

        }

        public async void LoadFilterData()
        {
            BankList = await Task.Run(() => LoadBankData());
            FromDate = ToDate = TodayDate = DateTime.Now;
            

        }

        private void ExecuteApplyFilterCommand()
        {

            try
            {
                ToDate = ToDate.AddDays(1); // To get correct result for ToDate (Missing one day result)
                int selectedbankId = SelectedBank.BankId;
                TransactionDtlsList.Clear();

                if (selectedbankId != -1 && !string.IsNullOrEmpty(UserName) && !string.IsNullOrWhiteSpace(UserName)) // For Specific Bank and Valid UserName
                {
                    TransactionDtlsList = allTransactionDtlData.Where(txndata => txndata.TransDate >= FromDate && txndata.TransDate <= ToDate
                                                                        && txndata.Username.ToLower() == UserName.ToLower() && txndata.BankID == selectedbankId).ToList();
                    
                }
                else if (selectedbankId == -1 && !string.IsNullOrEmpty(UserName) && !string.IsNullOrWhiteSpace(UserName)) // For All Bank and Valid UserName
                {
                    TransactionDtlsList = allTransactionDtlData.Where(txndata => txndata.TransDate >= FromDate && txndata.TransDate <= ToDate
                                                                        && txndata.Username.ToLower() == UserName.ToLower()).ToList(); 
                }

                else if (selectedbankId != -1 && string.IsNullOrEmpty(UserName) && string.IsNullOrWhiteSpace(UserName)) // For Specific Bank and Empty UserName
                {
                    TransactionDtlsList = allTransactionDtlData.Where(txndata => txndata.TransDate >= FromDate && txndata.TransDate <= ToDate
                                                                        && txndata.BankID == selectedbankId).ToList(); 
                }

                else if (selectedbankId == -1 && string.IsNullOrEmpty(UserName) && string.IsNullOrWhiteSpace(UserName)) // For All Bank and Empty UserName
                {
                    TransactionDtlsList = allTransactionDtlData.Where(txndata => txndata.TransDate >= FromDate && txndata.TransDate <= ToDate).ToList();
                }

                App.Current.MainPage.Navigation.PopModalAsync();
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - HomeViewModel - ExecuteApplyFilterCommand " + ex.Message.ToString());
            }
        }

        public async void LoadTransactionData()
        {
            IsBusyIndicator = true;

            TransactionDtlsList = await Task.Run(() => SaveTransactionDataToDb());

            IsBusyIndicator = false;

        }
        private async Task<List<TransactionDetails>> SaveTransactionDataToDb()
        {
            try
            {
                string resultData = await WebServiceCall.GetDataFromAPI("GetTransactionDetails", "");

                if (resultData != null)
                {
                    List<TransactionDetails> objListTransDtls = JsonConvert.DeserializeObject<List<TransactionDetails>>(resultData);

                    try
                    {
                        await App.TransDtlsDatabase.DeleteAllTransDetailsAsync();
                        foreach (TransactionDetails objTransDtls in objListTransDtls)
                        {
                            await App.TransDtlsDatabase.SaveTransDtlItemAsync(objTransDtls);
                        }

                        allTransactionDtlData = await App.TransDtlsDatabase.GetTransDtltemsAsync();
                        //recent20TransDtlList = Enumerable.Reverse(allTransactionDtlData).Take(20).Reverse().ToList();
                        recent20TransDtlList = allTransactionDtlData.Take(20).ToList();

                        return recent20TransDtlList;

                    }
                    catch (Exception ex)
                    {

                        ModCommon.LogErrors("ANDROID Error  - HomeViewModel - LoadTransactionData/Delete&Save [Inner] :" + ex.Message.ToString());
                        return null;
                    }

                }
                else
                {
                    CrossToastPopUp.Current.ShowToastError("No Transactions Found");
                    return null;
                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - HomeViewModel - LoadTransactionData :" + ex.Message.ToString());
                return null;
            }
        }


        private async Task<List<BankDetails>> LoadBankData()
        {
            try
            {
                string resultData = await WebServiceCall.GetDataFromAPI("GetBanks", "");

                if (resultData != null)
                {
                    List<BankDetails> bankListData = JsonConvert.DeserializeObject<List<BankDetails>>(resultData); ;
                    bankListData.Insert(0, new BankDetails { BankId = -1, BankName = "All" }); // Add "All" Bank Type to first position in the List
                    return bankListData;

                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - HomeViewModel - LoadBankData :" + ex.Message.ToString());
                return null;
            }
        }

        async void ExecuteRefreshCommand()
        {
            try
            {
                if (TransactionDtlsList != null)
                {
                    TransactionDtlsList.Clear();
                    allTransactionDtlData.Clear();
                    recent20TransDtlList.Clear();
                    LoadTransactionData();

                }
                else
                {
                    LoadTransactionData();
                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - HomeViewModel - ExecuteRefreshCommand :" + ex.Message.ToString());
            }
            // Stop refreshing
            IsRefreshing = false;
        }
    }
}
