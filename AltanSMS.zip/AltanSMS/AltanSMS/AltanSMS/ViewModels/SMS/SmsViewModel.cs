﻿using AltanSMS.Models;
using AltanSMS.Utils;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace AltanSMS.ViewModels.SMS
{
    public class SmsViewModel : BaseViewModel
    {
        // Page Fields
        private List<SMSDetails> _rowSMSList;
        public List<SMSDetails> RowSMSList
        {
            get { return _rowSMSList; }
            set
            {
                _rowSMSList = value;
                OnPropertyChanged();
            }
        }

        // Helper Fields
        bool isRefreshing;
        public bool IsRefreshing
        {
            get => isRefreshing;
            set
            {
                isRefreshing = value;
                OnPropertyChanged(nameof(IsRefreshing));
            }
        }

        List<SMSDetails> allSMSDtlData = null;

        // Commands
        public ICommand RefreshCommand { protected set; get; }

        public SmsViewModel()
        {
            LoadRowSMSList();
            RefreshCommand = new Command(ExecuteRefreshCommand);
        }

        private async void LoadRowSMSList()
        {
            RowSMSList = await Task.Run(() => LoadRowSMSListFromDB());
        }

        private async Task<List<SMSDetails>> LoadRowSMSListFromDB()
        {
            allSMSDtlData = await App.SmsDetailDatabase.GetSMSItemsAsync();
            return allSMSDtlData;

        }

       public async void ExecuteRefreshCommand()
        {
            try
            {
                if (RowSMSList != null)
                {
                    RowSMSList.Clear();
                    allSMSDtlData.Clear();
                    RowSMSList = await App.SmsDetailDatabase.GetSMSItemsAsync();
                }
                else
                {
                    RowSMSList = await App.SmsDetailDatabase.GetSMSItemsAsync();
                }
            }
            catch (Exception ex)
            {
                RowSMSList.Clear();
                allSMSDtlData.Clear();
                RowSMSList = await App.SmsDetailDatabase.GetSMSItemsAsync();
                ModCommon.LogErrors("ANDROID Error  - SmsViewModel - ExecuteRefreshCommand :" + ex.Message.ToString());
            }
            // Stop refreshing
            IsRefreshing = false;
        }
    }
}
