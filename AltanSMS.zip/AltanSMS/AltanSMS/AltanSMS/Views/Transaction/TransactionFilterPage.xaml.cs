﻿using AltanSMS.Utils;
using AltanSMS.ViewModels.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AltanSMS.Views.Transaction
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionFilterPage : ContentPage
    {
        //protected HomeViewModel objHomeViewModel => BindingContext as HomeViewModel;

        public TransactionFilterPage()
        {
            InitializeComponent();
            //BindingContext = new HomeViewModel();

        }

        private void Iconcrossfilter_Clicked(object sender, EventArgs e)
        {
            try
            {
                Navigation.PopModalAsync();
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error TransactionFilter -Iconcrossfilter_Clicked " + ex.Message.ToString());
            }
        }

        protected override async void OnAppearing()
        {
            //  SelectedIndex="0" in XAML not working

            BankPicker.SelectedIndex = 0;
        }
    }
}