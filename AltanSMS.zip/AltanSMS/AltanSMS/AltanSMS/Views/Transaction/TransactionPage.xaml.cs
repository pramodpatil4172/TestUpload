﻿using AltanSMS.Interfaces;
using AltanSMS.Utils;
using AltanSMS.ViewModels.Home;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AltanSMS.Views.Transaction
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TransactionPage : ContentPage
    {
        protected HomeViewModel objHomeViewModel => BindingContext as HomeViewModel;
        public TransactionPage()
        {
            InitializeComponent();
            //BindingContext = new HomeViewModel();
        }

        private void TransactionFilter_Clicked(object sender, EventArgs e)
        {
            if (Navigation.ModalStack.Count == 0 || Navigation.ModalStack.Last().GetType() != typeof(TransactionFilterPage))
            {
                Navigation.PushModalAsync(new TransactionFilterPage());
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            //objHomeViewModel.IsBusyIndicator = false;
            //App.objMainUserViewModel.IsEnableLogin = true;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            objHomeViewModel.LoadTransactionData();
            objHomeViewModel.LoadFilterData();
        }

        //private void StartService_Clicked(object sender, EventArgs e)
        //{
        //    DependencyService.Get<IBroadcastSMSReceiverService>().StartForegroundService();
        //}

        //private void StopService_Clicked(object sender, EventArgs e)
        //{
        //    DependencyService.Get<IBroadcastSMSReceiverService>().StopForegroundService();
        //}
    }

}