﻿using AltanSMS.Interfaces;
using AltanSMS.Utils;
using AltanSMS.ViewModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AltanSMS.Views.Login
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        protected LoginViewModel objLoginViewModel => BindingContext as LoginViewModel;

        public LoginPage()
        {
            InitializeComponent();
            BindingContext = new LoginViewModel();

            UserNameEntry.Completed += (object sender, EventArgs e) =>
            {
                PasswordEntry.Focus();
            };

            //CV_AdvertiseBanner.Source = ModCommon.BaseURL + "/APP/mobile/topbanner-android.asp";

        }

        private void OnTapPass(object sender, EventArgs args)
        {
            try
            {
                if (EyeOn.Opacity == 0)
                {
                    EyeOn.Opacity = 1;
                    EyeOff.Opacity = 0;
                    PasswordEntry.IsPassword = true;
                }
                else
                {
                    EyeOn.Opacity = 0;
                    EyeOff.Opacity = 1;
                    PasswordEntry.IsPassword = false;
                }

            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  Login-OnTapPass " + ex.Message.ToString());
            }
        }

        private void OnRemebrBtnClick(object sender, EventArgs e)
        {
            try
            {
                if (RemebrBtnChecked.Opacity == 0)
                {
                    RemebrBtnChecked.Opacity = 1;
                    RemebrBtnUnchecked.Opacity = 0;
                    Settings.IsRememberMe = true;
                }
                else
                {
                    RemebrBtnUnchecked.Opacity = 1;
                    RemebrBtnChecked.Opacity = 0;
                    Settings.IsRememberMe = false;
                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  Login-OnRemebrBtnClick " + ex.Message.ToString());
            }
        }


        protected override async void OnAppearing()
        {
            base.OnAppearing();

            try
            {
                // Fetch user name and password if saved in secure storage

                if (Settings.IsRememberMe)
                {
                    UserNameEntry.Text = await SecureStorage.GetAsync("LoginUserName");
                    PasswordEntry.Text = await SecureStorage.GetAsync("LoginUserPassword");
                    PhoneNumber.Text = await SecureStorage.GetAsync("LoginMobileNumber");
                    RemebrBtnChecked.Opacity = 1;
                }

            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  LoginPage - OnAppearing " + ex.Message.ToString());
            }
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            objLoginViewModel.IsBusyIndicator = false;
            //App.objMainUserViewModel.IsEnableLogin = true;
        }
    }
}