﻿using AltanSMS.ViewModels.SMS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AltanSMS.Views.RawSMS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RawSMSPage : ContentPage
    {
        protected SmsViewModel objSmsViewModel => BindingContext as SmsViewModel;

        public RawSMSPage()
        {
            InitializeComponent();
            BindingContext = new SmsViewModel();
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            objSmsViewModel.ExecuteRefreshCommand();
        }
    }
}