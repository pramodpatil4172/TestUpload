﻿using AltanSMS.Data;
using AltanSMS.Interfaces;
using AltanSMS.Utils;
using AltanSMS.Views;
using AltanSMS.Views.Login;
using System;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace AltanSMS
{
    public partial class App : Application
    {
        static SMSDetailsDatabase ObjSmsDetailDatabase;
        static TransactionDetailsDatabase ObjTransactionDetailsDatabase;

        public App()
        {
            InitializeComponent();

            GetPhonePermissions();
            MainPage = new NavigationPage(new LoginPage());
        }

        public static SMSDetailsDatabase SmsDetailDatabase
        {
            get
            {
                if (ObjSmsDetailDatabase == null)
                {
                    ObjSmsDetailDatabase = new SMSDetailsDatabase();
                }
                return ObjSmsDetailDatabase;
            }
        }

        public static TransactionDetailsDatabase TransDtlsDatabase
        {
            get
            {
                if (ObjTransactionDetailsDatabase == null)
                {
                    ObjTransactionDetailsDatabase = new TransactionDetailsDatabase();
                }
                return ObjTransactionDetailsDatabase;
            }
        }

        #region GetPhonePermissions
        private async void GetPhonePermissions()
        {
            try
            {
                // Check Phone and Message Permissions
                var phonePermissionstatus = await Permissions.CheckStatusAsync<Permissions.Phone>();
                var smsPermissionstatus = await Permissions.CheckStatusAsync<Permissions.Sms>();

                if (phonePermissionstatus != PermissionStatus.Granted)
                {
                    phonePermissionstatus = await Permissions.RequestAsync<Permissions.Phone>();
                }

                if (smsPermissionstatus != PermissionStatus.Granted)
                {
                    smsPermissionstatus = await Permissions.RequestAsync<Permissions.Sms>();
                }

                if (phonePermissionstatus != PermissionStatus.Granted || smsPermissionstatus != PermissionStatus.Granted)
                {
                    // Close Application if User does not give Phone or SMS permission
                    var CloseApp = DependencyService.Get<ICloseApplication>();
                    if (CloseApp != null)
                    {
                        CloseApp.closeApplication();
                    }
                }

                // Ask for Permission Again and Again
                //while (status != PermissionStatus.Granted)
                //{
                //    status = await Permissions.RequestAsync<Permissions.Phone>();
                //}

                // When Phone and SMS both permission are granted then allow  to Login
                if (phonePermissionstatus == PermissionStatus.Granted && smsPermissionstatus == PermissionStatus.Granted)
                {
                    MainPage = new NavigationPage(new LoginPage());
                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  LoginViewModel - GetPhonePermissions " + ex.Message.ToString());
            }
        }
        #endregion

        protected override void OnStart()
        {

        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }

    }
}
