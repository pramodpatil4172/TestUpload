﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Essentials;


namespace AltanSMS.Utils
{
    public static class Settings
    {
        public static bool IsRememberMe
        {
            get => Preferences.Get(nameof(IsRememberMe), false);
            set => Preferences.Set(nameof(IsRememberMe), value);
        }

        public static string SenderID
        {
            get => Preferences.Get(nameof(SenderID), "");
            set => Preferences.Set(nameof(SenderID), value);
        }

        public static string SenderID2
        {
            get => Preferences.Get(nameof(SenderID2), "");
            set => Preferences.Set(nameof(SenderID2), value);
        }

        public static string SenderID3
        {
            get => Preferences.Get(nameof(SenderID3), "");
            set => Preferences.Set(nameof(SenderID3), value);
        }

        public static bool IsSmsServiceStarted
        {
            get => Preferences.Get(nameof(IsSmsServiceStarted), false);
            set => Preferences.Set(nameof(IsSmsServiceStarted), value);
        }

    }
}
