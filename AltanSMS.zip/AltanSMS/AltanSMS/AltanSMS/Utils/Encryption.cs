﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;


namespace AltanSMS.Utils
{
    class Encryption : IDisposable
    {
        string PassPhrase = "8P:*A*s?7J82b#?FpDgU4'[P%t`A}8gWe.qwZGbe796ZuT,G,<)z39$q(!P&rMum";
        string SaltValue = "zPU}/'A^ep";
        int PasswordIterations = 2;
        string InitVector = "sy#rbZL7Bwh<s[-V";

        byte[] plainTextBytes;
        byte[] keyBytes;
        byte[] cipherTextBytes;
        RijndaelManaged encryptor_symmetricKey, decryptor_symmetricKey;
        ICryptoTransform encryptor, decryptor;
        MemoryStream encryptor_memoryStream, decryptor_memoryStream;
        CryptoStream encryptor_cryptoStream, decryptor_cryptoStream;

        byte[] plainTextBytes1;
        byte[] cipherTextBytes1;

        public Encryption()
        {
            try
            {
                Rfc2898DeriveBytes ObjRfc2898 = new Rfc2898DeriveBytes(Encoding.UTF8.GetBytes(PassPhrase), Encoding.ASCII.GetBytes(SaltValue), PasswordIterations);
                keyBytes = ObjRfc2898.GetBytes(256 / 8);

                encryptor_symmetricKey = new RijndaelManaged();
                encryptor_symmetricKey.Mode = CipherMode.CBC;
                encryptor_symmetricKey.Padding = PaddingMode.PKCS7;
                encryptor = encryptor_symmetricKey.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(InitVector));

                decryptor_symmetricKey = new RijndaelManaged();
                decryptor_symmetricKey.Mode = CipherMode.CBC;
                decryptor_symmetricKey.Padding = PaddingMode.PKCS7;
                decryptor = decryptor_symmetricKey.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(InitVector));

                ObjRfc2898.Dispose();
            }
            catch { }
        }

        public string Encrypt(string plainText)
        {
            try
            {
                string encrypted;
                using (RijndaelManaged rijAlg = new RijndaelManaged())
                {
                    ICryptoTransform encryptor = rijAlg.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(InitVector));

                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(plainText);
                            }
                            encrypted = Convert.ToBase64String(msEncrypt.ToArray());
                        }
                    }
                }
                return encrypted;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        public string Decrypt(string cipherText)
        {
            try
            {
                cipherTextBytes1 = Convert.FromBase64String(cipherText);
                string OutDecryptedText = null;
                using (RijndaelManaged rijAlg = new RijndaelManaged())
                {
                    // Create a decrytor to perform the stream transform.
                    ICryptoTransform decryptor = rijAlg.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(InitVector));

                    // Create the streams used for decryption.
                    using (MemoryStream msDecrypt = new MemoryStream(cipherTextBytes1))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {

                                // Read the decrypted bytes from the decrypting stream
                                // and place them in a string.
                                OutDecryptedText = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
                return OutDecryptedText;
            }
            catch
            {
                return string.Empty;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            try
            {
                encryptor.Dispose();
                decryptor.Dispose();
                decryptor_symmetricKey.Dispose();
                encryptor_symmetricKey.Dispose();
                if (encryptor_memoryStream != null)
                    encryptor_memoryStream.Dispose();
                if (decryptor_memoryStream != null)
                    decryptor_memoryStream.Dispose();
                if (encryptor_cryptoStream != null)
                    encryptor_cryptoStream.Dispose();
                if (decryptor_cryptoStream != null)
                    decryptor_cryptoStream.Dispose();
            }
            catch { }
        }
    }
}
