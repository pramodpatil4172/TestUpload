﻿using AltanSMS.Interfaces;
using AltanSMS.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace AltanSMS.Utils
{
    public class ModCommon
    {

        //public static string WebAPi = "http://ws1.altan.club/SMSAppWS/SMSApp.aspx/";  //prod server
        public static string WebAPi = "";  //prod

        public static string MainAPIService_URL = "http://ws1.pecanent.com/PECANWS/pecanapi.aspx/";
        public static string SkinName = "ALTAN";
        public static async Task LoadDefaults()
        {
            try
            {
                Encryption ObjEncrypt = new Encryption();
                string Inputs = ObjEncrypt.Encrypt(string.Concat("1|", SkinName, "|", GetRandomString()));
                ClientVerion ObjAllData = new ClientVerion
                {
                    ClientToken = Inputs
                };
                var ObjResult = await WebServiceCall.GetDataDefaultAPI("GetClientDetails/" + SkinName, ObjAllData);
                var ResultData = JsonConvert.DeserializeObject<object>(ObjResult);
                if (ResultData != null)
                {
                    if (ResultData.ToString() != "")
                    {
                        var DecryptData = ObjEncrypt.Decrypt(ResultData.ToString()).Split('|');
                        WebAPi = DecryptData[11];
                        //string MainWebServiceUrl = DecryptData[3] + "GetSMSAppURL";

                        //// Get SMS URL
                        //var objSmsAppUrl = await WebServiceCall.GetDataFromAPI(MainWebServiceUrl, "");
                        //var Result = JsonConvert.DeserializeObject(objSmsAppUrl.ToString());
                        //WebAPi = Result.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                LogErrors("ANDROID Error - ModCommon - LoadDefaults " + ex.Message.ToString());

            }
            //return Task.CompletedTask;
        }

        public static string GetRandomString()
        {
            try
            {
                string path = Path.GetRandomFileName();
                path = path.Replace(".", "");
                return path;
            }
            catch (Exception)
            {
                return "Encryption";
            }
        }

        public class ClientVerion
        {
            public string ClientToken { get; set; }
        }


        #region GetAndroidId
        public static string GetIMEINumber()
        {
            return DependencyService.Get<IDeviceInfo>().GetIdentifier();
        }
        #endregion

        #region SendErrorLog
        public static void LogErrors(string logError)
        {
            ErrorLog errorLog = new ErrorLog();

            errorLog.error = logError;

           WebServiceCall.GetDataFromAPI("LogError", errorLog);
        }

        public class ErrorLog
        {
            public string error { get; set; }
        }
        #endregion
    }


}
