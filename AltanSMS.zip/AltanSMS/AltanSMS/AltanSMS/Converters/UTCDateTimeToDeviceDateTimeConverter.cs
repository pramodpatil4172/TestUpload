﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using AltanSMS.Utils;
using Xamarin.Forms;

namespace AltanSMS.Converters
{
    public class UTCDateTimeToDeviceDateTimeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            try
            {

                if (value != null)
                {
                    DateTime parsedDateTimeFormat = DateTime.Parse(value.ToString());
                    DateTime DeviceDateTime = DateTime.SpecifyKind(parsedDateTimeFormat, DateTimeKind.Utc);
                    DateTime localVersion = DeviceDateTime.ToLocalTime();

                    return localVersion.ToString("dd/MM/yy hh:mm tt");

                }
                else
                {
                    return value;
                }
            }
            catch (Exception)
            {
                return value;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
