﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using Xamarin.Forms;

namespace AltanSMS.CustomControls
{
    public class CustomEntry : Entry
    {
        public static readonly BindableProperty IsCustomPasswordProperty = BindableProperty.Create(nameof(IsCustomtPassword), typeof(bool), typeof(CustomEntry), false);

        public bool IsCustomtPassword
        {
            get => (bool)GetValue(IsCustomPasswordProperty);
            set => SetValue(IsCustomPasswordProperty, value);
        }

        public static readonly BindableProperty IsAllLetersCapProperty = BindableProperty.Create(nameof(IsAllLetersCap), typeof(bool), typeof(CustomEntry), false);

        public bool IsAllLetersCap
        {
            get => (bool)GetValue(IsAllLetersCapProperty);
            set => SetValue(IsAllLetersCapProperty, value);
        }

        public static readonly BindableProperty IsOnlyNumbersProperty = BindableProperty.Create(nameof(IsOnlyNumbers), typeof(bool), typeof(CustomEntry), false);

        public bool IsOnlyNumbers
        {
            get => (bool)GetValue(IsOnlyNumbersProperty);
            set => SetValue(IsOnlyNumbersProperty, value);
        }

        public static readonly BindableProperty IsTxtSearchMemberProperty = BindableProperty.Create(nameof(IsTxtSearchMember), typeof(bool), typeof(CustomEntry), false);

        public bool IsTxtSearchMember
        {
            get => (bool)GetValue(IsTxtSearchMemberProperty);
            set => SetValue(IsTxtSearchMemberProperty, value);
        }

        public static readonly BindableProperty IsOnlyDecimalProperty = BindableProperty.Create(nameof(IsOnlyDecimal), typeof(bool), typeof(CustomEntry), false);

        public bool IsOnlyDecimal
        {
            get => (bool)GetValue(IsOnlyDecimalProperty);
            set => SetValue(IsOnlyDecimalProperty, value);
        }

        public static readonly BindableProperty IsHideBGProperty = BindableProperty.Create(nameof(IsHideBG), typeof(bool), typeof(CustomEntry), false);

        public bool IsHideBG
        {
            get => (bool)GetValue(IsHideBGProperty);
            set => SetValue(IsHideBGProperty, value);
        }

        public static readonly BindableProperty IsShowBgProperty = BindableProperty.Create(nameof(IsShowBG), typeof(bool), typeof(CustomEntry), false);

        public bool IsShowBG
        {
            get => (bool)GetValue(IsShowBgProperty);
            set => SetValue(IsShowBgProperty, value);
        }

        public static readonly BindableProperty isStaticBorderLessEntryProperty = BindableProperty.Create(nameof(IsBorderless), typeof(bool), typeof(CustomEntry), false);

        public bool IsBorderless
        {
            get => (bool)GetValue(isStaticBorderLessEntryProperty);
            set => SetValue(isStaticBorderLessEntryProperty, value);
        }

        public static readonly BindableProperty isStaticIsLoginUserNameBGEntryProperty = BindableProperty.Create(nameof(IsLoginUserNameBG), typeof(bool), typeof(CustomEntry), false);

        public bool IsLoginUserNameBG
        {
            get => (bool)GetValue(isStaticIsLoginUserNameBGEntryProperty);
            set => SetValue(isStaticIsLoginUserNameBGEntryProperty, value);
        }

        public static readonly BindableProperty isStaticIsPassBGEntryProperty = BindableProperty.Create(nameof(IsLoginPassBG), typeof(bool), typeof(CustomEntry), false);

        public bool IsLoginPassBG
        {
            get => (bool)GetValue(isStaticIsPassBGEntryProperty);
            set => SetValue(isStaticIsPassBGEntryProperty, value);
        }

        public static readonly BindableProperty isStaticIsPlaneTextBG = BindableProperty.Create(nameof(IsPlaneTextBG), typeof(bool), typeof(CustomEntry), false);
        public bool IsPlaneTextBG
        {
            get => (bool)GetValue(isStaticIsPlaneTextBG);
            set => SetValue(isStaticIsPlaneTextBG, value);
        }

        public static readonly BindableProperty IsShowBgPropertyCashier = BindableProperty.Create(nameof(IsShowBGC), typeof(bool), typeof(CustomEntry), false);

        public bool IsShowBGC
        {
            get => (bool)GetValue(IsShowBgPropertyCashier);
            set => SetValue(IsShowBgPropertyCashier, value);
        }

        public static readonly BindableProperty IsSpecialCharacters = BindableProperty.Create(nameof(IsSpecialC), typeof(bool), typeof(CustomEntry), false);

        public bool IsSpecialC
        {
            get => (bool)GetValue(IsSpecialCharacters);
            set => SetValue(IsSpecialCharacters, value);
        }

        public static readonly BindableProperty IsPlayerNoteEntry = BindableProperty.Create(nameof(IsPlayerEntry), typeof(bool), typeof(CustomEntry), false);

        public bool IsPlayerEntry
        {
            get => (bool)GetValue(IsSpecialCharacters);
            set => SetValue(IsSpecialCharacters, value);
        }
    }

}