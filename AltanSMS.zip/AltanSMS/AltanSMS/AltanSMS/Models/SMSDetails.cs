﻿using AltanSMS.Utils;
using SQLite;
using System;

namespace AltanSMS.Models
{
    public class SMSDetails
    {
        [PrimaryKey, AutoIncrement]
        public int SMSId { get; set; }
        public string UniqueRandomKey { get; set; }
        public string SMSSenderID { get; set; }
        public string RawSMS { get; set; }
        public DateTime SMSReceivedDateTime { get; set; }
        public bool SMSStatus { get; set; }
        public int failedSMSProcessCounter { get; set; }

    }
}
