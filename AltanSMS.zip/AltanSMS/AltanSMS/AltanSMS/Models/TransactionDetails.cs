﻿using Newtonsoft.Json;
using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace AltanSMS.Models
{
    public class TransactionDetails
    {
        [JsonProperty("RowID")]
        public int RowID { get; set; }

        [JsonProperty("SenderID")]
        public string SenderID { get; set; }

        [JsonProperty("TransDate")]
        public DateTime TransDate { get; set; } 

        [JsonProperty("Amount")]
        public float Amount { get; set; }

        [JsonProperty("Balance")]
        public float Balance { get; set; }

        [JsonProperty("BankID")]
        public int BankID { get; set; }

        [JsonProperty("Message")]
        public string Message { get; set; }

        [JsonProperty("Username")]
        public string Username { get; set; }

        [JsonProperty("TransactionStatus")]
        public bool TransactionStatus { get; set; } 

        [JsonProperty("TransStatusReason")]
        public string TransStatusReason { get; set; }

    }

    public class BankDetails
    {

        [JsonProperty("BankId")]
        public int BankId { get; set; }

        [JsonProperty("BankName")]
        public string BankName { get; set; }

    }
}
