﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AltanSMS.Data.Helpers;
using AltanSMS.Models;
using AltanSMS.Utils;
using Plugin.Toast;
using SQLite;

namespace AltanSMS.Data
{
    public class SMSDetailsDatabase
    {
        static readonly Lazy<SQLiteAsyncConnection> lazyInitializer = new Lazy<SQLiteAsyncConnection>(() =>
        {
            return new SQLiteAsyncConnection(Constants.DatabasePath, Constants.Flags);
        });

        static SQLiteAsyncConnection Database => lazyInitializer.Value;
        static bool initialized = false;

        public SMSDetailsDatabase()
        {
            InitializeAsync().SafeFireAndForget(false);
        }

        async Task InitializeAsync()
        {
            if (!initialized)
            {
                if (!Database.TableMappings.Any(m => m.MappedType.Name == typeof(SMSDetails).Name))
                {
                    await Database.CreateTablesAsync(CreateFlags.None, typeof(SMSDetails)).ConfigureAwait(false);
                }
                initialized = true;
            }
        }

        public Task<List<SMSDetails>> GetSMSItemsAsync()
        {
            return Database.Table<SMSDetails>().ToListAsync();
        }

        public Task<List<SMSDetails>> GetSMSItemsNotDoneAsync()
        {
            return Database.QueryAsync<SMSDetails>("SELECT * FROM [SMSDetails] WHERE [Done] = 0");
        }

        public Task<SMSDetails> GetSMSItemAsync(int id)
        {
            return Database.Table<SMSDetails>().Where(i => i.SMSId == id).FirstOrDefaultAsync();
        }

        public Task<int> SaveSMSItemAsync(SMSDetails SmsItem)
        {
            try
            {
                if (SmsItem.SMSId != 0)
                {
                    return Database.UpdateAsync(SmsItem);
                }
                else
                {
                    SmsItem.UniqueRandomKey = ModCommon.GetRandomString();
                    return Database.InsertAsync(SmsItem);
                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - SMSDetailsDatabase - SaveSMSItemAsync :" + ex.Message.ToString());
                return null;
            }
        }

        public Task<int> DeleteSMSItemAsync(SMSDetails SmsItem)
        {
            return Database.DeleteAsync(SmsItem);
        }

        public Task<SMSDetails> GetSavedSMSDetails()
        {
            try
            {
                //return Database.ExecuteScalarAsync<int>("SELECT  MAX(SMSId) from SMSDetails", null);
                //return Database.QueryAsync<SMSDetails>("SELECT MAX(SMSId) FROM SMSDetails");
                return Database.Table<SMSDetails>().OrderByDescending(x => x.SMSId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - SMSDetailsDatabase - SendBankDetailsToServer :" + ex.Message.ToString());
                return null;
            }
        }

        public Task<int> DeleteAllSMSItemAsync()
        {
            return Database.DeleteAllAsync<SMSDetails>();
        }

        public Task<List<SMSDetails>> GetUnProcessedSMS()
        {
            return Database.QueryAsync<SMSDetails>("SELECT * FROM [SMSDetails] WHERE [SMSStatus] = false");
        }

    }
}
