﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AltanSMS.Data.Helpers;
using AltanSMS.Models;
using AltanSMS.Utils;
using SQLite;

namespace AltanSMS.Data
{
    public class TransactionDetailsDatabase
    {
        static readonly Lazy<SQLiteAsyncConnection> lazyInitializer = new Lazy<SQLiteAsyncConnection>(() =>
        {
            return new SQLiteAsyncConnection(Constants.DatabasePath, Constants.Flags);
        });

        static SQLiteAsyncConnection Database => lazyInitializer.Value;
        static bool initialized = false;

        public TransactionDetailsDatabase()
        {
            InitializeAsync().SafeFireAndForget(false);
        }

        async Task InitializeAsync()
        {
            if (!initialized)
            {
                if (!Database.TableMappings.Any(m => m.MappedType.Name == typeof(TransactionDetails).Name))
                {
                    await Database.CreateTablesAsync(CreateFlags.None, typeof(TransactionDetails)).ConfigureAwait(false);
                }
                initialized = true;
            }
        }

        public Task<List<TransactionDetails>> GetTransDtltemsAsync()
        {
            return Database.Table<TransactionDetails>().ToListAsync();

        }

        public Task<List<TransactionDetails>> GetTransDtlItemsNotDoneAsync()
        {
            return Database.QueryAsync<TransactionDetails>("SELECT * FROM [TransactionDetails] WHERE [Done] = 0");
        }

        public Task<TransactionDetails> GetTransDtlItemAsync(int id)
        {
            return Database.Table<TransactionDetails>().Where(i => i.RowID == id).FirstOrDefaultAsync();
        }

        public Task<int> SaveTransDtlItemAsync(TransactionDetails TransDtlsItems)
        {
            return Database.InsertAsync(TransDtlsItems);
            //if (TransDtlsItems.RowID != 0)
            //{
            //    return Database.UpdateAsync(TransDtlsItems);
            //}
            //else
            //{
            //    return Database.InsertAsync(TransDtlsItems);
            //}
        }

        public Task<int> DeleteTransDtlItemAsync(TransactionDetails TransDtlsItems)
        {
            return Database.DeleteAsync(TransDtlsItems);
        }

        public Task<TransactionDetails> GetSavedTransDetails()
        {
            try
            {
                //return Database.ExecuteScalarAsync<int>("SELECT  MAX(SMSId) from TransactionDetails", null);
                //return Database.QueryAsync<TransactionDetails>("SELECT MAX(SMSId) FROM TransactionDetails");
                return Database.Table<TransactionDetails>().OrderByDescending(x => x.RowID).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - HomeViewModel - SendBankDetailsToServer :"+ ex.Message.ToString());
                return null;
            }
        }

        public Task<int> DeleteAllTransDetailsAsync()
        {
            return Database.DeleteAllAsync<TransactionDetails>();
        }

    }
}
