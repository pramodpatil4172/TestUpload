﻿using System;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using AltanSMS.Utils;

namespace AltanSMS.Services
{
    class DataService
    {
        public static async Task<dynamic> GetDataFromService(string APIFunction_Name, string jsonData)
        {
            string responseBody = String.Empty;
            try
            {
                //var newurl = ModCommon.WebAPi + url;
                //HttpClient client = new HttpClient(handler);
                HttpClient client = new HttpClient();
                StringContent queryString = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(ModCommon.WebAPi + APIFunction_Name, queryString).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    response.EnsureSuccessStatusCode();
                    responseBody = await response.Content.ReadAsStringAsync();
                    //responseBody = responseBody.Replace("\"", "");
                }
            }
            catch (Exception ex)
            {
                //ModCommon.TraceLog("Error DataService GetDataFromService : " + ex.Message);
                responseBody = null; //"false";
            }
            return responseBody;
        }

        public static async Task<dynamic> GetDefaultSettings(string APIFunction_Name, string jsonData)
        {
            string responseBody = String.Empty;
            try
            {
                //var newurl = ModCommon.MainAPIService_URL + APIFunction_Name;
                //HttpClient client = new HttpClient(handler);
                HttpClient client = new HttpClient();
                StringContent queryString = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(ModCommon.MainAPIService_URL + APIFunction_Name, queryString).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    response.EnsureSuccessStatusCode();
                    responseBody = await response.Content.ReadAsStringAsync();
                    //responseBody = responseBody.Replace("\"", "");
                }
            }
            catch (Exception ex)
            {
                //ModCommon.TraceLog("Error DataService GetDefaultSettings : " + ex.Message);
                responseBody = null; //"false";
            }
            return responseBody;
        }

    }
}
