﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AltanSMS.Services
{
    class WebServiceCall
    {
        public static async Task<string> GetDataFromAPI(string API_FunctionName, dynamic objToSend)
        {
            dynamic results = null;
            try
            {
                string data = JsonConvert.SerializeObject(objToSend);
                results = await DataService.GetDataFromService(API_FunctionName, data).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
            return results;
        }

        public static async Task<string> GetDataDefaultAPI(string API_FunctionName, dynamic objTable)
        {
            dynamic results = null;
            try
            {
                string data = JsonConvert.SerializeObject(objTable);
                results = await DataService.GetDefaultSettings(API_FunctionName, data).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
            return results;
        }
    }
}
