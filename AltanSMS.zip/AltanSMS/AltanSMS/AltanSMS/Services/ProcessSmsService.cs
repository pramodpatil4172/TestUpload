﻿using AltanSMS.Models;
using AltanSMS.Utils;
using Newtonsoft.Json;
using Plugin.Toast;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Timers;
using AltanSMS.ViewModels;

namespace AltanSMS.Services
{
    public class ProcessSmsService : BaseViewModel
    {
        private static Timer unProcessedSmsTimer;
        private static Timer InternetCheckTimer;

        public ProcessSmsService()
        {
            try
            {

                MessagingCenter.Unsubscribe<string[]>(this, "messageBody");
                MessagingCenter.Subscribe<string[]>(this, "messageBody", (messageBodyDetails) =>
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        SaveSMSDetailsToDB(messageBodyDetails);
                    });
                });


                MessagingCenter.Unsubscribe<string[]>(this, "InvalidMessageBody");
                MessagingCenter.Subscribe<string[]>(this, "InvalidMessageBody", (invalidMessageBodyDetails) =>
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        ModCommon.LogErrors("***** Android Alert *******  - ProcessSmsService - Invalid SMS :" + "Sender : " + invalidMessageBodyDetails[0].ToString()
                            + " RawSMS: " + invalidMessageBodyDetails[1].ToString() + " DateTime: " + invalidMessageBodyDetails[2].ToString());
                    });
                });

                HandleUnProcessedSMS();
                HandleInternetConnection();

            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - Constructor :" + ex.Message.ToString());
            }
        }


        public async void SaveSMSDetailsToDB(string[] msgBodyDetails)
        {
            try
            {
                SMSDetails objSMSDetails = new SMSDetails
                {
                    SMSSenderID = msgBodyDetails[0],
                    RawSMS = msgBodyDetails[1],
                    SMSReceivedDateTime = Convert.ToDateTime(msgBodyDetails[2])
                };

                int isAddedtoDB = await App.SmsDetailDatabase.SaveSMSItemAsync(objSMSDetails); // 1 - Added , 0 - Failed

                if (isAddedtoDB == 1)
                {
                    SMSDetails SmsDetails = await App.SmsDetailDatabase.GetSavedSMSDetails();
                    SendSMSDetails(SmsDetails);

                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - SaveSMSDetailsToDB :" + ex.Message.ToString());
            }

        }

        internal async void SendSMSDetails(SMSDetails msgBodyDetails)
        {
            try
            {
                var resultData = await WebServiceCall.GetDataFromAPI("RecieveSMS", msgBodyDetails);
                dynamic Result = JsonConvert.DeserializeObject(resultData.ToString());

                if (Result.Status.ToString() == "1")
                {
                    msgBodyDetails.SMSStatus = (Result.Status == "1") ? true : false;

                    await App.SmsDetailDatabase.SaveSMSItemAsync(msgBodyDetails);
                    //CrossToastPopUp.Current.ShowToastSuccess("Successfully Sent" + msgBodyDetails.SMSStatus);

                }
                else
                {

                    msgBodyDetails.failedSMSProcessCounter = msgBodyDetails.failedSMSProcessCounter + 1; // Increment processing failed counter
                    await App.SmsDetailDatabase.SaveSMSItemAsync(msgBodyDetails);

                    ModCommon.LogErrors("ANDROID - ProcessSmsService - SendSMSDetails - ReceiveSMS (failed response)  :" + JsonConvert.SerializeObject(msgBodyDetails));

                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - SendSMSDetails :" + ex.Message.ToString());
            }
        }

        private  async void OnTimedEventForUnProcessedSMS(Object source, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                List<SMSDetails> UnProcessedSMSList = await App.SmsDetailDatabase.GetUnProcessedSMS();

                foreach (SMSDetails objSMSDetails in UnProcessedSMSList)
                {
                    if (objSMSDetails.failedSMSProcessCounter < 3) // If failed 3 times on resend don't process that SMS
                    {
                        SendSMSDetails(objSMSDetails);
                    }
                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - OnTimedEventForUnProcessedSMS :" + ex.Message.ToString());
            }

        }

        private void OnTimedEventForCheckInternetConnection(Object source, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                if (IsNotConnectedToInternet)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        CrossToastPopUp.Current.ShowToastError("AltanSMS: Please check your internet connection");
                    });

                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - OnTimedEventForCheckInternetConnection :" + ex.Message.ToString());
            }
        }

        private void HandleUnProcessedSMS()
        {
            try
            {
                // Create a timer and set a 5 minutes interval.
                unProcessedSmsTimer = new System.Timers.Timer();
                unProcessedSmsTimer.Interval = 300000;

                // Hook up the Elapsed event for the timer. 
                unProcessedSmsTimer.Elapsed += OnTimedEventForUnProcessedSMS;

                // Have the timer fire repeated events (true is the default)
                unProcessedSmsTimer.AutoReset = true;

                // Start the timer
                unProcessedSmsTimer.Enabled = true;
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - HandleUnProcessedSMS :" + ex.Message.ToString());
            }
        }


        private void HandleInternetConnection()
        {
            try
            {
                // Create a timer and set a 5 second interval.
                InternetCheckTimer = new System.Timers.Timer();
                InternetCheckTimer.Interval = 5000;

                // Hook up the Elapsed event for the timer. 
                InternetCheckTimer.Elapsed += OnTimedEventForCheckInternetConnection;

                // Have the timer fire repeated events (true is the default)
                InternetCheckTimer.AutoReset = true;

                // Start the timer
                InternetCheckTimer.Enabled = true;
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - ProcessSmsService - HandleInternetConnection :" + ex.Message.ToString());
            }
        }


    }
}
