﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.Text.RegularExpressions;
using Android.Telephony;
using Java.Lang;
using Xamarin.Forms;
using AltanSMS.Utils;
using AltanSMS.Services;

namespace AltanSMS.Droid.BackGroundService
{
    [BroadcastReceiver(Enabled = true)]
    public class SMSBroadcastReceiver : BroadcastReceiver
    {
        private const string IntentAction = "android.provider.Telephony.SMS_RECEIVED";
        //private static readonly string Sender = "+918080841670";
        ProcessSmsService objProcessSmsService;

        // Some times Sender Id does not contain + symbol, so removed + and checked
        static string removedplusfromSenderId2 = Settings.SenderID2.Remove(0, 1);
        static string removedplusfromSenderId3 = Settings.SenderID3.Remove(0, 1);

        private static readonly string[] SenderIDs = { Settings.SenderID, Settings.SenderID2, Settings.SenderID3, removedplusfromSenderId2, removedplusfromSenderId3 };

        private static readonly string[] MessageBodyKeywordSet = { "Uldegdel", "Utga", "ULDEGDEL" }; 
        public override void OnReceive(Context context, Intent intent)
        {
            try
            {
                if (objProcessSmsService == null)
                {
                    objProcessSmsService = new ProcessSmsService();
                }

                if (intent.Action != IntentAction) return;

                //Sender = Settings.SenderID;
                var bundle = intent.Extras;
                if (bundle == null) return;
                var pdus = bundle.Get("pdus");
                // var castedPdus = JNIEnv.GetArray(pdus.Handle);
                var castedPdus = JNIEnv.GetArray<Java.Lang.Object>(pdus.Handle);
                var msgs = new SmsMessage[castedPdus.Length];
                var sb = new System.Text.StringBuilder();
                string sender = null;
                for (var i = 0; i < msgs.Length; i++)
                {
                    var bytes = new byte[JNIEnv.GetArrayLength(castedPdus[i].Handle)];
                    JNIEnv.CopyArray(castedPdus[i].Handle, bytes);
                    string format = bundle.GetString("format");
                    msgs[i] = SmsMessage.CreateFromPdu(bytes, format);
                    if (sender == null)
                        sender = msgs[i].OriginatingAddress;
                    sb.Append(string.Format("SMS From: {0}{1}Body: {2}{1}", msgs[i].OriginatingAddress,
                        System.Environment.NewLine, msgs[i].MessageBody));
                    //Toast.MakeText(context, sb.ToString(), ToastLength.Long).Show();
                    //Log.Error("Pramod", sb.ToString());

                    var msgBody = msgs[i].MessageBody;

                    //sender = "Khan Bank"; // +132525, +133133, 133133 Comment this later

                    //Toast.MakeText(context, "Received SMS" + msgBody.ToString(), ToastLength.Short).Show(); //Comment this later

                    bool isSenderValid = SenderIDs.Any(s => sender.Contains(s));
                    if (!isSenderValid)
                    {
                        string[] invalidSmS = { sender, msgBody, DateTime.Now.ToString() };
                        MessagingCenter.Send(invalidSmS, "InvalidMessageBody");
                        return;
                    }

                    bool foundKeyword = MessageBodyKeywordSet.Any(k => msgBody.Contains(k));

                    if (!foundKeyword) return;

                    //string[] messagebodyToBeSent = {  Sender, msgBody, DateTime.Now.ToString() };
                    string[] messagebodyToBeSent = { sender, msgBody, DateTime.Now.ToString() };

                    //MessagingCenter.Send<RegisterSecondPageModel, string>(new RegisterSecondPageModel(), "OtpReceived", code);
                    //Toast.MakeText(context, "Receiver1" + msgBody.ToString(), ToastLength.Short).Show();

                    MessagingCenter.Send(messagebodyToBeSent, "messageBody");
                }
            }
            catch (System.Exception ex)
            {
                //Toast.MakeText(context, ex.Message, ToastLength.Long).Show();
                ModCommon.LogErrors("ANDROID Error  OnReceive-SmsReceiver " + ex.Message.ToString());

            }
        }

        //private static string[] SplitIntoStringArray(string stringToBeSplit)
        //{

        //    string[] splittedMsgArray = stringToBeSplit.Split(' ');

        //    return splittedMsgArray;
        //}

    }
}

