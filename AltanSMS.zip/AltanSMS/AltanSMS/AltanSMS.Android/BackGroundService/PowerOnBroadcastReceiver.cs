﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AltanSMS.Services;
using AltanSMS.Utils;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Xamarin.Forms;

namespace AltanSMS.Droid.BackGroundService
{
    [BroadcastReceiver(Enabled = true, Exported = true, DirectBootAware = true)]
    [IntentFilter(new string[] { Intent.ActionBootCompleted, Intent.ActionLockedBootCompleted })]
    public class PowerOnBroadcastReceiver : BroadcastReceiver
    {
        public override void OnReceive(Context context, Intent intent)
        {
            try
            {
                if (intent.Action.Equals(Intent.ActionBootCompleted))
                {
                    //Toast.MakeText(context, "************Received intent Power ON ************!", ToastLength.Long).Show();
                    MessagingCenter.Send<App, bool>((App)Xamarin.Forms.Application.Current, "StartServiceOnBoot", Settings.IsSmsServiceStarted);
                }
            }
            catch (Exception ex)
            {
                ModCommon.LogErrors("ANDROID Error  - PowerOnBroadcastReceiver :" + ex.Message.ToString());
            }
        }
    }
}