﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AltanSMS.Utils;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Plugin.Toast;

namespace AltanSMS.Droid.BackGroundService
{
    [Service]
    public class BroadcastReceiverService : Service
    {
        private static SMSBroadcastReceiver objSMSBroadcastReceiver;
        private static PowerOnBroadcastReceiver objPowerOnBroadcastReceiver;

        public override IBinder OnBind(Intent intent)
        {
            return null;
        }

        public override void OnCreate()
        {
                RegisterBroadcastReceiver();
        }

        public override void OnDestroy()
        {
            Application.Context.UnregisterReceiver(objSMSBroadcastReceiver);
            Application.Context.UnregisterReceiver(objPowerOnBroadcastReceiver);

            objSMSBroadcastReceiver = null;
            objPowerOnBroadcastReceiver = null;

        }

        private void RegisterBroadcastReceiver()
        {
            try
            {
                objSMSBroadcastReceiver = new SMSBroadcastReceiver();
                IntentFilter filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
                Application.Context.RegisterReceiver(objSMSBroadcastReceiver, filter);

                objPowerOnBroadcastReceiver = new PowerOnBroadcastReceiver();
                IntentFilter filterpoweron = new IntentFilter(Intent.ActionBootCompleted);
                Application.Context.RegisterReceiver(objPowerOnBroadcastReceiver, filterpoweron);
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - BroadcastReceiverService - RegisterBroadcastReceiver :" + ex.Message.ToString());
            }

        }
    }
}