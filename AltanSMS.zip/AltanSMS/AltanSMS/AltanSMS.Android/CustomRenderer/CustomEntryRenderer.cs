﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Views;
using Xamarin.Forms;
using AltanSMS.Droid.CustomRenderer;
using Xamarin.Forms.Platform.Android;
using Android.Text;
using System.ComponentModel;
using Android.Graphics;
using AltanSMS.CustomControls;
using Android.Support.V4.Content;

[assembly: ExportRenderer(typeof(CustomEntry), typeof(NativeEntryRenderer))]

namespace AltanSMS.Droid.CustomRenderer
{
    class NativeEntryRenderer : EntryRenderer
    {
        public NativeEntryRenderer(Context context) : base(context)
        {
            AutoPackage = false;
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {
                //Control.SetPadding(25, 25, 25, 25);

                Control.InputType = InputTypes.TextFlagNoSuggestions;
                //Control.Background = Resources.GetDrawable(Resource.Drawable.EntryBorderStyle);
                //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.EntryBorderStyle);

                Control.Gravity = GravityFlags.CenterVertical;

                Control.Typeface = Typeface.Monospace;

                var element = Element as CustomEntry;

                if (element.IsAllLetersCap)
                {
                    Control.InputType = InputTypes.TextFlagCapCharacters;
                }
                if (element.IsOnlyNumbers)
                {
                    Control.InputType = InputTypes.ClassNumber;
                }
                if (element.IsCustomtPassword)
                {
                    Control.InputType = InputTypes.TextVariationPassword | InputTypes.ClassText;
                }
                if (element.IsTxtSearchMember)
                {
                    //Control.SetPadding(10, 0, 0, 0);
                    //Control.Background = new Android.Graphics.Drawables.ColorDrawable(Android.Graphics.Color.Transparent);
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.EntrySearchBGImage);
                    Control.SetPadding(80, 10, 25, 10);
                }
                if (element.IsOnlyDecimal)
                {
                    Control.InputType = InputTypes.ClassPhone;
                }

                if (element.IsHideBG)
                {
                    Control.SetPadding(20, 0, 25, 0);
                    Control.Background = new Android.Graphics.Drawables.ColorDrawable(Android.Graphics.Color.Transparent);
                }

                if (element.IsShowBG)
                {
                    //Control.Background = Resources.GetDrawable(Resource.Drawable.EntryBGImage);
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.EntryBGImage);
                    Control.SetPadding(20, 10, 25, 10);
                }

                if (element.IsLoginUserNameBG)
                {
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.UsernameBG);
                    Control.SetPadding(50, 0, 0, 0);
                }
                if (element.IsBorderless)
                {
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.BorderlessEntry);
                    Control.SetPadding(50, 0, 0, 0);
                }
                if (element.IsLoginPassBG)
                {
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.PasswordBG);
                    Control.SetPadding(50, 0, 0, 0);
                }
                if (element.IsPlaneTextBG)
                {
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.PlaneTextBG);
                    Control.SetPadding(50, 0, 0, 0);

                }
                if (element.IsShowBGC)
                {
                    //Control.Background = Resources.GetDrawable(Resource.Drawable.EntryBGImage);
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.CashierEntryBGImage);
                    Control.SetPadding(20, 10, 25, 10);
                }

                if (element.IsPlayerEntry)
                {
                    //Control.Background = Resources.GetDrawable(Resource.Drawable.EntryBGImage);
                    //Control.Background = ContextCompat.GetDrawable(Context, Resource.Drawable.PlayerEntryBG);
                    Control.SetPadding(50, 0, 0, 0);
                }
            }
        }
    }
}
