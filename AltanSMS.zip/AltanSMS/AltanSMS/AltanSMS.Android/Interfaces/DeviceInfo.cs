﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AltanSMS.Droid.Interfaces;
using AltanSMS.Interfaces;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Xamarin.Forms;
using Android.Provider;
using Android.Telephony;

[assembly: Xamarin.Forms.Dependency(typeof(DeviceInfo))]
namespace AltanSMS.Droid.Interfaces
{
    class DeviceInfo : IDeviceInfo
    {

        public string GetIdentifier()
        {
            string IMEINumber = string.Empty;
            try
            {
                IMEINumber = Settings.Secure.GetString(Forms.Context.ContentResolver, Settings.Secure.AndroidId);

            }
            catch (Exception ex)
            {
                AltanSMS.Utils.ModCommon.LogErrors("ANDROID Error GetIdentifier Android=" + ex.Message);
            }
            return IMEINumber;
        }
    }
}