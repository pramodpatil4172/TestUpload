﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AltanSMS.Droid.BackGroundService;
using AltanSMS.Droid.Interfaces;
using AltanSMS.Interfaces;
using AltanSMS.Utils;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Plugin.Toast;
using Xamarin.Forms;

[assembly: Xamarin.Forms.Dependency(typeof(SMSForegroundService))]

namespace AltanSMS.Droid.Interfaces
{
    [Service]
    public class SMSForegroundService : Service, IBroadcastSMSReceiverService
    {
        public const int SERVICE_RUNNING_NOTIFICATION_ID = 10000;
        static Intent service;

        public void StartForegroundService()
        {

            try
            {
                var intent = new Intent(Android.App.Application.Context, typeof(SMSForegroundService));

                if (Android.OS.Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.O)
                {
                    Android.App.Application.Context.StartForegroundService(intent);
                }
                else
                {
                    Android.App.Application.Context.StartService(intent);
                }
            }
            catch (Exception ex)
            {

                ModCommon.LogErrors("ANDROID Error  - SMSForegroundService - StartForegroundService :" + ex.Message.ToString());
            }
        }

        public void StopForegroundService()
        {
            // StopForeground(true);

            //var intent = new Intent(this, typeof(DependentService));
            //StopService(intent);
            //if (Android.OS.Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.N)
            //{
            //    //StopForeground(StopForegroundFlags.Remove);

            //    Android.App.Application.Context.StopService(intent);
            //}
            //else
            //{
            //    //StopForeground(true);
            //    Android.App.Application.Context.StopService(intent);
            //    StopService(new Intent(this, typeof(SmsReceiver)));

            //}
        }
        public override IBinder OnBind(Intent intent)
        {
            return null;
        }

        public override void OnCreate()
        {

        }
        public override StartCommandResult OnStartCommand(Intent intent, StartCommandFlags flags, int startId)
        {
            CreateNotificationChannel();
            string notificationBody = "Altan SMS Service Running";

            var notification = new Notification.Builder(this, "10111")
            //.SetContentTitle(Resources.GetString(Resource.String.app_name))
            .SetContentTitle("AltanSMS")
            .SetContentText(notificationBody)
            .SetSmallIcon(Resource.Drawable.icon)
            .SetOngoing(true)
            .Build();

            // Enlist this instance of the service as a foreground service
            StartForeground(SERVICE_RUNNING_NOTIFICATION_ID, notification);

            // do your work

            try
            {
                service = new Intent(this, typeof(BroadcastReceiverService));
                StartService(service);
            }
            catch (Exception ex) 
            {

                ModCommon.LogErrors("ANDROID Error  - SMSForegroundService - StartCommandResult :" + ex.Message.ToString());
            }


            return StartCommandResult.Sticky;
        }


        void CreateNotificationChannel()
        {
            if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            {
                // Notification channels are new in API 26 (and not a part of the
                // support library). There is no need to create a notification
                // channel on older versions of Android.
                return;
            }

            //var channelName = Resources.GetString(Resource.String.channel_name);
            //var channelDescription = GetString(Resource.String.channel_description);
            var channelName = "AltanChannel";
            var channelDescription = "AltanChannelDesc";
            var channel = new NotificationChannel("10111", channelName, NotificationImportance.Default)
            {
                Description = channelDescription
            };

            var notificationManager = (NotificationManager)GetSystemService(NotificationService);
            notificationManager.CreateNotificationChannel(channel);
        }

        public override void OnDestroy()
        {
            //StopService(new Intent(this, typeof(BroadcastReceiverService)));

            // Remove the notification from the status bar.
            var notificationManager = (NotificationManager)GetSystemService(NotificationService);
            notificationManager.Cancel(SERVICE_RUNNING_NOTIFICATION_ID);

            base.OnDestroy();
            //StopService(new Intent(this, typeof(BroadcastReceiverService)));
            //service = null;
        }

    }
}