﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using AltanSMS.Droid.Interfaces;
using AltanSMS.Interfaces;
using Xamarin.Forms;
[assembly: Dependency(typeof(CloseApplication))]

namespace AltanSMS.Droid.Interfaces
{
    class CloseApplication : ICloseApplication
    {
        public void closeApplication()
        {
            var activity = (Activity)Forms.Context; 
            try
            {
                //activity.FinishAffinity();
                //activity.Finish();

                if (Android.OS.Build.VERSION.SdkInt >= Android.OS.BuildVersionCodes.Lollipop)
                {
                    activity.FinishAndRemoveTask();
                }
                else
                {
                    activity.FinishAffinity();
                }
                activity.Finish();
                Android.OS.Process.KillProcess(Android.OS.Process.MyPid());
            }
            catch (Exception ex)
            {
                var Error = ex.Message;
            }
        }
    }
}